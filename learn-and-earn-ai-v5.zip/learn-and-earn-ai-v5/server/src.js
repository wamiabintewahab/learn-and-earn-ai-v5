'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const port = Number(process.env.PORT || 3000);
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({ limit: '16kb' }));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'learn-and-earn-ai-api', authConfigured: false }));

// Intentionally no fake login/signup endpoint. Authentication needs a chosen provider,
// verified configuration, database, email flow, and deployment secrets.
app.use('/api/auth', (_req, res) => res.status(501).json({
  error: 'Authentication is not configured.',
  nextStep: 'Choose and configure a trusted authentication provider before enabling accounts.'
}));

app.use((err, _req, res, _next) => {
  // Do not expose stack traces or internal errors to clients.
  console.error('Request error:', err.message);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});

app.listen(port, () => console.log(`API starter listening on port ${port}`));

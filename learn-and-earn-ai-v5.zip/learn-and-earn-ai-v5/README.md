# Learn&Earn AI — Version 0.5

A multi-page dark-theme prototype with separate Home, Videos, Learn, Coding Playground, About, Privacy, Security, Login, and Sign-up pages.

## Run the frontend locally
1. Open the `public` folder.
2. Open `index.html` in a modern browser.
3. Use the top navigation to move between separate pages.

For a local static server (recommended), from the project root run:
```bash
python -m http.server 8000 --directory public
```
Then visit `http://localhost:8000`.

## Backend starter (optional)
Requires Node.js 18+.
```bash
cd server
npm install
npm start
```
The starter provides basic security headers, JSON size limits, API rate limiting, and `/api/health`. Authentication routes intentionally return HTTP 501 until a real provider/database/email flow is configured. It is not production-ready.

## Important limitations
- Login and signup are visual demo forms only. They do not create accounts or transmit/store form data.
- Video cards are placeholders, not live streaming. Add licensed videos through a suitable video host/CDN and configure access/retention rules.
- The coding playground is a limited demonstration runner, not a secure general-purpose sandbox.
- No database, email verification, password reset, analytics, payments, AI API, or account data storage is connected.
- Privacy and security pages are starter notices, not legal advice or certification.
- GitHub Pages can host the static frontend, but it cannot run this Node backend. Use a separate supported server host for the backend and configure environment variables there.
- Never commit passwords, API keys, private URLs, `.env`, or real user data to a public repository.

## Suggested next production steps
1. Decide the hosting region, audience/age policy, and data you truly need.
2. Choose a maintained authentication provider; configure email verification, reset, MFA options, session handling, and account deletion.
3. Choose a database; implement authorization checks, parameterized queries, backups, and data-retention/deletion policies.
4. Select a video hosting provider and use licensed media; configure playback access and privacy settings.
5. Add server-side validation, CSRF protection where relevant, rate limiting, security headers, logging without sensitive data, and abuse controls.
6. Have an independent security review and privacy/legal review before inviting real users.

document.addEventListener('DOMContentLoaded',()=>{
 const search=document.getElementById('videoSearch');
 if(search) search.addEventListener('input',()=>{const q=search.value.toLowerCase();document.querySelectorAll('.video-card').forEach(c=>c.hidden=!c.dataset.search.includes(q));});
 document.querySelectorAll('[data-demo]').forEach(b=>b.addEventListener('click',()=>{const n=document.getElementById('videoNotice');if(n){n.style.display='block';n.textContent=`“${b.dataset.demo}” is a demo card. Add a licensed video file or configure a video host to enable playback.`;n.scrollIntoView({behavior:'smooth',block:'nearest'});}}));
 const editor=document.getElementById('codeEditor'),out=document.getElementById('codeOutput');
 if(editor&&out){
  const initial=editor.value;
  document.getElementById('resetCode').addEventListener('click',()=>{editor.value=initial;out.textContent='Editor reset. Select Run example.';});
  document.getElementById('clearOutput').addEventListener('click',()=>out.textContent='');
  document.getElementById('runCode').addEventListener('click',()=>{
   const src=editor.value; const lines=src.split(/\r?\n/);const result=[];
   if(src.length>5000){out.textContent='Error: demo input is limited to 5,000 characters.';return;}
   for(const raw of lines){const line=raw.trim();if(!line||line.startsWith('//')||/^(const|let)\s+\w+\s*=/.test(line))continue;
    const m=line.match(/^console\.log\((.*)\);?$/);
    if(!m){out.textContent='Demo runner supports only simple console.log(...) lines and basic const/let declarations. Unsupported line: '+line;return;}
    const arg=m[1].trim();
    if(/^(['"]).*\1$/.test(arg)){result.push(arg.slice(1,-1));continue;}
    if(/^-?\d+(\s*[+\-*/]\s*-?\d+)?$/.test(arg)){try{const nums=arg.match(/-?\d+/g).map(Number);const op=arg.match(/[+\-*/]/);if(!op)result.push(String(nums[0]));else {let v=op[0]==='+'?nums[0]+nums[1]:op[0]==='-'?nums[0]-nums[1]:op[0]==='*'?nums[0]*nums[1]:nums[0]/nums[1];result.push(String(v));}}catch{out.textContent='Could not parse number.';return;}continue;}
    const variable=arg.match(/^\w+$/);const decl=src.match(new RegExp('(?:const|let)\\s+'+arg+'\\s*=\\s*([\\s\\S]*?);'));
    if(variable&&decl&&/^(['"]).*\1$/.test(decl[1].trim())){result.push(decl[1].trim().slice(1,-1));continue;}
    out.textContent='This example runner intentionally supports a small subset only. Try console.log("Hello") or console.log(2 + 3).';return;
   }
   out.textContent=result.length?result.join('\n'):'Ran successfully (no output).';
  });
 }
 document.querySelectorAll('#demoAuthForm').forEach(f=>f.addEventListener('submit',e=>{e.preventDefault();const m=document.getElementById('authMessage');if(m)m.textContent='Demo only: no account was created and no form data was sent or stored.';f.reset();}));
});
